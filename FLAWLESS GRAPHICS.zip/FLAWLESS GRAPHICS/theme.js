// Automatic theme handled via CSS media query
console.log("Automatic light/dark mode applied based on system preference.");
